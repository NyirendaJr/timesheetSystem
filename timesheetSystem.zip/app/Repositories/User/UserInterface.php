<?php
namespace App\Repositories\User;
interface UserInterface {

}
