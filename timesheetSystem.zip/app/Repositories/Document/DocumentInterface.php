<?php
namespace App\Repositories\Document;

interface DocumentInterface
{
  //public function findAll();
  //public function findById();
  //public function delete();
  //public function update();
}


 ?>
