<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Timesheet - Home</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="<?php echo e(asset('assets/css/metisMenu.min.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="<?php echo e(asset('assets/css/morris.css')); ?>" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <style media="screen">
    #brand{
      color: #005581;
      /* font-size: 25px; */
      font-weight: bolder;
      font-family: arial, sans-serif;
      font-weight: bold;
      /* text-shadow: 1px 1px 2px rgba(150, 150,150, 0.75); */
    }
    </style>
</head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/" id="brand">
                  TIMESHEET MANAGEMENT SYSTEM
                </a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                      <span class="badge">0</span>
                        <i class="fa fa-envelope fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">
                                        <em>Yesterday</em>
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>Read All Messages</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                  <?php if(Auth::user()->role == "Manager"): ?>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <?php if($mdnots->count() > 0): ?>
                          <span class="badge"><?php echo e($mdnots->count()); ?></span>
                        <?php else: ?>
                          <span class="badge">0</span>
                        <?php endif; ?>
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <?php $__empty_1 = true; $__currentLoopData = $mdnots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-file fa-fw"></i><?php echo e($value->filedesc); ?>&nbsp
                                    <span class="pull-right text-muted small">by <?php echo e($value->user_id); ?>

                                    <span class="label label-primary"><?php echo e($value->created_at); ?></span></span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Alerts</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-center">
                           You haven't any notification
                        </li>
                        <li class="divider"></li>
                        <?php endif; ?>
                    </ul>
                    <!-- /.dropdown-alerts -->
                    <?php elseif(Auth::user()->role == "HR"): ?>
                      <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                          <?php if($hrnots->count() > 0): ?>
                            <span class="badge"><?php echo e($hrnots->count()); ?></span>
                          <?php else: ?>
                            <span class="badge">0</span>
                          <?php endif; ?>
                          <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                      </a>
                      <ul class="dropdown-menu dropdown-alerts">
                          <?php $__empty_1 = true; $__currentLoopData = $hrnots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <li>
                              <a href="#">
                                  <div>
                                      <i class="fa fa-file fa-fw"></i><?php echo e($value->filedesc); ?>&nbsp
                                      <span class="pull-right text-muted small">by <?php echo e($value->user_id); ?>

                                      <span class="label label-primary"><?php echo e($value->created_at); ?></span></span>
                                  </div>
                              </a>
                          </li>
                          <li class="divider"></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <li>
                             You haven't any notification
                          </li>
                          <?php endif; ?>
                          <li>
                              <a class="text-center" href="#">
                                  <strong>See All Alerts</strong>
                                  <i class="fa fa-angle-right"></i>
                              </a>
                          </li>
                      </ul>
                  <?php elseif(Auth::user()->role == "Staff"): ?>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <?php if($stnots->count() > 0): ?>
                          <span class="badge"><?php echo e($stnots->count()); ?></span>
                        <?php else: ?>
                          <span class="badge">0</span>
                        <?php endif; ?>
                        <i class="fa fa-bell fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <?php $__empty_1 = true; $__currentLoopData = $stnots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <a href="#">
                                <div>
                                    <i class="fa fa-file fa-fw"></i><?php echo e($value->filedesc); ?>&nbsp
                                    <span class="pull-right text-muted small">by <?php echo e($value->user_id); ?>

                                    <span class="label label-primary"><?php echo e($value->created_at); ?></span></span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Alerts</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-center">
                           You haven't any notification
                        </li>
                        <li class="divider"></li>
                        <?php endif; ?>
                    </ul>
                  <?php endif; ?>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                  <a id="navbarDropdown" class="dropdown-toggle" href="#" data-toggle="dropdown">
                    <i class="fa fa-user fa-fw"></i>
                     <?php echo e(Auth::user()->lastname); ?>  (<?php echo e(Auth::user()->role); ?>)<span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-user">
                      <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                         <i class="fa fa-sign-out fa-fw"></i>
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                      </li>
                  </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                          <img src="<?php echo e(asset('images/logo.png')); ?>" height="100" width="220" class="mekonsultlogo" alt="HLB Mekonsult Logo">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li><a href="<?php echo e(URL::to('/home')); ?>"><i class="fa fa-home fa-fw"></i> Home</a></li>
                        <li><a href="#"><i class="fa fa-pencil fa-fw"></i> Write Message</a></li>
                        <li>
                        <li>
                           <a href="<?php echo e(URL::to('/sent')); ?>"><i class="fa fa-file fa-fw"></i> Sent Document</a>
                        </li>
                        <li>
                           <a href="<?php echo e(URL::to('/received')); ?>"><i class="fa fa-file fa-fw"></i> Received Document</a>
                        </li>

                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                       <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
        <!-- <div class="footer text-center sticky-bottom" style="background-color: #ccc;">
             Copyright (c) 2018 Copyright Holder All Rights Reserved.
        </div> -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('assets/css/metisMenu.min.js')); ?>"></script>
    <!-- Morris Charts JavaScript -->
    <script src="<?php echo e(asset('assets/js/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/morris-data.js')); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <!-- DataTables JavaScript -->
   <script src="<?php echo e(asset('assets/datatables/js/jquery.dataTables.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/datatables-responsive/dataTables.responsive.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/sb-admin-2.min.js')); ?>"></script>
   <script>
       $(document).ready(function() {
           $('#dataTables-example').DataTable({
               responsive: true
           });
       });
   </script>
</body>
</html>
