@extends('layouts.app')
@section('content')
<div class="container text-center">
 <div class="starter-template">
     <img src="images/logo.png" height="121" class="mekonsultlogo" alt="HLB Mekonsult Logo">
   <h3 style="color: #616161;font-family: arial, sans-serif;text-transform: uppercase;font-weight: bold;color: #005983;text-shadow: 1px 1px 2px rgba(150, 150,150, 0.75);">Integrity | Professionalism | Team Work | Excellence</h3>
   <p class="lead" style="font-family: arial, sans-serif;">Understanding Client's Needs and Developing Economical and Practical Business Solutions</p>
 </div>
</div><!-- /.container -->
@endsection
