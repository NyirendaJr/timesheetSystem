<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-3">
            <div class="login-panel panel panel-default" style="margin-top: 10%;width: 600px;">
                <div class="panel-heading">
                    <h3 class="panel-title">Registration Form</h3>
                </div>
                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row">
                              <label for="regNo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Reg Number')); ?></label>

                              <div class="col-md-6">
                                  <input id="regNo" type="text" class="form-control<?php echo e($errors->has('regNo') ? ' is-invalid' : ''); ?>" name="regNo" value="<?php echo e(old('regNo')); ?>" required autofocus>

                                  <?php if($errors->has('regNo')): ?>
                                      <span class="invalid-feedback" role="alert" style="color: #ff0000">
                                          <strong><?php echo e($errors->first('regNo')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="firstname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('First Name')); ?></label>

                              <div class="col-md-6">
                                  <input id="firstname" type="text" class="form-control<?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus>

                                  <?php if($errors->has('firstname')): ?>
                                      <span class="invalid-feedback" role="alert" style="color: #ff0000">
                                          <strong><?php echo e($errors->first('firstname')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="lastname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label>

                              <div class="col-md-6">
                                  <input id="lastname" type="text" class="form-control<?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus>

                                  <?php if($errors->has('lastname')): ?>
                                      <span class="invalid-feedback" role="alert" style="color: #ff0000">
                                          <strong><?php echo e($errors->first('lastname')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>

                          <div class="form-group row">
                              <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                              <div class="col-md-6">
                                  <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                  <?php if($errors->has('email')): ?>
                                      <span class="invalid-feedback" role="alert" style="color: #ff0000">
                                          <strong><?php echo e($errors->first('email')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>

                          <!-- <div class="form-group row">
                              <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                              <div class="col-md-6">
                                  <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                  <?php if($errors->has('email')): ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($errors->first('email')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div> -->

                          <div class="form-group row">
                              <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                              <div class="col-md-6">
                                  <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                  <?php if($errors->has('password')): ?>
                                      <span class="invalid-feedback" role="alert" style="color: #ff0000">
                                          <strong><?php echo e($errors->first('password')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>

                          <div class="form-group row">
                              <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                              <div class="col-md-6">
                                  <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                              </div>
                          </div>

                          <div class="form-group row mb-0">
                              <div class="col-md-6 offset-md-4">
                                  <button type="submit" class="btn btn-primary">
                                      <?php echo e(__('Register')); ?>

                                  </button>
                              </div>
                          </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>